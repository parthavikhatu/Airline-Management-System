
import java.awt.HeadlessException;
import javax.swing.JOptionPane;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;



/**
 *
 * @author Mitali Chaudhari
 */
public class Add_Flight_Details extends javax.swing.JFrame {
    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    

    /**
     * Creates new form Add_Flight_Details
     */
    public Add_Flight_Details() {
        initComponents();
        conn=javaconnect.ConnectDb();
       
        Random();
        fetch();
    }
    
    public void Random(){
        Random rd=new Random();
        fid.setText(""+rd.nextInt(1000+1));
        
    }
    public void fetch(){
        try{
            String sql="select * from flights ";
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
            jtable.setModel(DbUtils.resultSetToTableModel(rs));
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    @SuppressWarnings("unchecked")
    private void initComponents() {//GEN-BEGIN:initComponents

        jLabel2 = new javax.swing.JLabel();
        fid = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        atime = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        dtime = new javax.swing.JTextField();
        fprice = new javax.swing.JTextField();
        Date = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtable = new javax.swing.JTable();
        Add_Flight = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Delete = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        Search = new javax.swing.JButton();
        home = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        from = new javax.swing.JComboBox<>();
        to = new javax.swing.JComboBox<>();
        fname = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1366, 768));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Flight Id:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 87, 34));
        getContentPane().add(fid, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 169, 34));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Flight Name:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, 34));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("From");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 87, 34));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("To");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 260, 87, 34));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Date:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, 60, 34));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Arrival Time:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 140, 100, 34));

        atime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atimeActionPerformed(evt);
            }
        });
        getContentPane().add(atime, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 140, 170, 34));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Departure Time:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 200, -1, 34));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Flight price:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 260, 112, 34));
        getContentPane().add(dtime, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 200, 170, 34));
        getContentPane().add(fprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 260, 170, 34));
        getContentPane().add(Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 80, 170, 34));

        jtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Flight Id", "Flight Name", "From", "To", "Date", "Arrival Time", "Departure Time", "Flight Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jtable);
        if (jtable.getColumnModel().getColumnCount() > 0) {
            jtable.getColumnModel().getColumn(0).setResizable(false);
            jtable.getColumnModel().getColumn(1).setResizable(false);
            jtable.getColumnModel().getColumn(2).setResizable(false);
            jtable.getColumnModel().getColumn(3).setResizable(false);
            jtable.getColumnModel().getColumn(4).setResizable(false);
            jtable.getColumnModel().getColumn(5).setResizable(false);
            jtable.getColumnModel().getColumn(6).setResizable(false);
            jtable.getColumnModel().getColumn(7).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 380, 920, 270));

        Add_Flight.setBackground(new java.awt.Color(204, 0, 0));
        Add_Flight.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add_Flight.setForeground(new java.awt.Color(255, 255, 255));
        Add_Flight.setText("Add");
        Add_Flight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_FlightActionPerformed(evt);
            }
        });
        getContentPane().add(Add_Flight, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 80, 160, 40));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        jLabel1.setText("Add Flight Details");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 221, 46));

        Delete.setBackground(new java.awt.Color(204, 0, 0));
        Delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delete.setForeground(new java.awt.Color(255, 255, 255));
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 200, 160, 40));

        Update.setBackground(new java.awt.Color(204, 0, 0));
        Update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update.setForeground(new java.awt.Color(255, 255, 255));
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 140, 160, 40));

        Search.setBackground(new java.awt.Color(204, 0, 0));
        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search.setForeground(new java.awt.Color(255, 255, 255));
        Search.setText("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        getContentPane().add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 80, 160, 40));

        home.setBackground(new java.awt.Color(204, 0, 0));
        home.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        home.setForeground(new java.awt.Color(255, 255, 255));
        home.setText("Home");
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });
        getContentPane().add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 140, 160, 40));

        Exit.setBackground(new java.awt.Color(204, 0, 0));
        Exit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        getContentPane().add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 200, 160, 40));

        from.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MUMBAI", "DELHI", "BANGALORE", "PUNE", "KOLKATA", "GOA", "HYDERABAD", "CHENNAI" }));
        getContentPane().add(from, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 170, 30));

        to.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MUMBAI", "DELHI", "BANGALORE", "PUNE", "KOLKATA", "GOA", "HYDERABAD", "CHENNAI" }));
        getContentPane().add(to, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 170, 30));

        fname.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "IndiGo", "Air India", "SpiceJet", "Go First", "AirAsia India", "Vistara", "Alliance Air", "TruJet" }));
        getContentPane().add(fname, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 170, 30));

        jLabel10.setIcon(new javax.swing.ImageIcon("E:\\images\\A.jpg")); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }//GEN-END:initComponents

    private void Add_FlightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_FlightActionPerformed
        // TODO add your handling code here:
        DateFormat da=new SimpleDateFormat("yyyy-MM-dd");
        String date=da.format(Date.getDate());
        {
        try{
            String sql="insert into flights(Flight_Id,Flight_Name,Source,Destination,Date,Arrival_Time,Departure_Time,Flight_Price)values(?,?,?,?,?,?,?,?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, fid.getText());
            pst.setString(2, (String) fname.getSelectedItem());
            pst.setString(3, (String) from.getSelectedItem());
            pst.setString(4, (String) to.getSelectedItem());
            pst.setString(5,date);
            pst.setString(6, atime.getText());
            pst.setString(7, dtime.getText());
            pst.setString(8, fprice.getText());
            
            
            
            pst.execute();
            fetch();
            
             
             
            JOptionPane.showMessageDialog(null, "registered");
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    }//GEN-LAST:event_Add_FlightActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        // TODO add your handling code here:
        String sql="DELETE FROM flights WHERE Flight_Id = ?";
        
        
         
        
            try {
                pst=conn.prepareStatement(sql);
                int id = Integer.parseInt(fid.getText());
                 
                    pst.setInt(1, id);
                    pst.executeUpdate();
                     fetch();
                    JOptionPane.showMessageDialog(null, "Flight Details Deleted");
                    
                //if(!fid.getText().equals("Flight_Id")){
                    
                    
                   
                
                 
                 
               
                //PreparedStatement pst = conn.prepareStatement("DELETE FROM flight WHERE Flight_Id = ?");
                //int id = Integer.parseInt(fid.getText());
                //pst.setInt(1, id);
                //pst.executeUpdate();
                
               // }
                //else{
                    //JOptionPane.showMessageDialog(null, "Product Not Deleted : No Id To Delete");
            
        //}
                
                
                
            } 
            catch(HeadlessException | NumberFormatException | SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
            
            
        
        
            
        
    }//GEN-LAST:event_DeleteActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        // TODO add your handling code here:
        DateFormat da=new SimpleDateFormat("yyy-MM-dd");
        String date=da.format(Date.getDate());
        try{
            String sql="update flights set Flight_Name=?, Source=?, Destination=?, Date=?, Arrival_Time=?, Departure_Time=?, Flight_Price=? where Flight_Id=?";
            pst=conn.prepareStatement(sql);
            pst.setString(8, fid.getText());
            pst.setString(1, (String) fname.getSelectedItem());
            pst.setString(2, (String) from.getSelectedItem());
            pst.setString(3, (String) to.getSelectedItem());
            pst.setString(4,date);
            pst.setString(5, atime.getText());
            pst.setString(6, dtime.getText());
            pst.setString(7, fprice.getText());
            pst.executeUpdate();
             fetch();
            JOptionPane.showMessageDialog(null,"Update Successful");
            
            
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
    }//GEN-LAST:event_UpdateActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
        // TODO add your handling code here:
        String sql="select * from flights where Flight_Id=?";
        try{
             pst=conn.prepareStatement(sql);
             pst.setString(1, fid.getText());
             rs=pst.executeQuery();
             if(rs.next()){
                 String add1=rs.getString("Flight_Name");
                 fname.setSelectedItem(add1);
                 String add2=rs.getString("Source");
                 from.setSelectedItem(add2);
                 String add3=rs.getString("Destination");
                 to.setSelectedItem(add3);
                 String Dob=rs.getString("Date");
                java.util.Date date1 =   new SimpleDateFormat("yyyy-MM-dd").parse(Dob);
                Date.setDate(date1);
                String add5=rs.getString("Arrival_Time");
                atime.setText(add5);
                String add6=rs.getString("Departure_Time");
                dtime.setText(add6);
                String add7=rs.getString("Flight_Price");
                fprice.setText(add7);
             }else{
                JOptionPane.showMessageDialog(null, " This Flght is not registered ");

            }
            
        }catch(HeadlessException | SQLException | ParseException e){
            JOptionPane.showMessageDialog(null,e);
        }
        
    }//GEN-LAST:event_SearchActionPerformed

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        main ob=new main();
        ob.setVisible(true);
      
    }//GEN-LAST:event_homeActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        // TODO add your handling code here:
        JFrame frame=new JFrame("EXIT");
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","EXIT",
                JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
        {
            System.exit(0);
        }
        
       
    }//GEN-LAST:event_ExitActionPerformed

    private void atimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atimeActionPerformed

    }//GEN-LAST:event_atimeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Add_Flight_Details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_Flight;
    private com.toedter.calendar.JDateChooser Date;
    private javax.swing.JButton Delete;
    private javax.swing.JButton Exit;
    private javax.swing.JButton Search;
    private javax.swing.JButton Update;
    private javax.swing.JTextField atime;
    private javax.swing.JTextField dtime;
    private javax.swing.JTextField fid;
    private javax.swing.JComboBox<String> fname;
    private javax.swing.JTextField fprice;
    private javax.swing.JComboBox<String> from;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtable;
    private javax.swing.JComboBox<String> to;
    // End of variables declaration//GEN-END:variables
}
